"""Reconstruct the original float32 total power without loss."""
from pathlib import Path
import numpy as np
p=Path(__file__).resolve().parent
with np.load(p/'waterfall_componentes.npz',allow_pickle=False) as d:
    arrays={k:d[k] for k in d.files}
arrays['total_power']=arrays['noise_power']+arrays['satellite_power']+arrays['solar_power']
np.savez_compressed(p/'waterfall.npz',**arrays)
print('Created',p/'waterfall.npz')
