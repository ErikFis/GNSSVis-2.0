# Dados GNSSVis 2.0

Este pacote contém todos os dados da simulação de 24 horas. Para reduzir o
tamanho sem perda numérica, a potência total, redundante, foi omitida do NPZ:

```python
total_power = noise_power + satellite_power + solar_power
```

Execute `python reconstruir_waterfall.py` para criar o `waterfall.npz` original
com as quatro componentes. Requer NumPy. A igualdade exata em float32 foi
verificada antes do envio. Frequências, tempos e componentes não sofreram
reamostragem ou perda de precisão. Os gráficos PNG estão na galeria do GitHub.
